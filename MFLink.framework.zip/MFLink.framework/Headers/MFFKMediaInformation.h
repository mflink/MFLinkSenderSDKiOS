//
//  Copyright (c) 2013 - 2015 MoreFun (Beijing) Technology Co., Ltd.. All rights reserved.
//

@class MFFKMediaMetadata;

typedef NS_ENUM(NSInteger, MFFKMediaStreamType) {
    /** A stream type of "none". */
            MFFKMediaStreamTypeNone = 0,
    /** A buffered stream type. */
            MFFKMediaStreamTypeBuffered = 1,
    /** A live stream type. */
            MFFKMediaStreamTypeLive = 2,
    /** An unknown stream type. */
            MFFKMediaStreamTypeUnknown = 99,
};

/**
 * A class that aggregates information about a media item.
 */
@interface MFFKMediaInformation : NSObject

/**
 * The stream type.
 */
@property(nonatomic) MFFKMediaStreamType streamType;

/**
 * The content (MIME) type.
 */
@property(nonatomic, copy) NSString *contentType;

/**
 * The media item metadata.
 */
@property(nonatomic, strong) MFFKMediaMetadata *metadata;

/**
 * The length of time for the stream, in seconds.
 */
@property(nonatomic) NSTimeInterval streamDuration;

/**
 * The custom data, if any.
 */
@property(nonatomic, strong) id customData;

/**
 * Designated initializer.
 *
 * @param contentID The content ID.
 * @param streamType The stream type.
 * @param contentType The content (MIME) type.
 * @param metadata The media item metadata.
 * @param streamDuration The stream duration.
 * @param customData The custom application-specific data.
 */
- (id)initWithContentID:(NSString *)contentID
             streamType:(MFFKMediaStreamType)streamType
            contentType:(NSString *)contentType
               metadata:(MFFKMediaMetadata *)metadata
         streamDuration:(NSTimeInterval)streamDuration
             customData:(id)customData;

/** @cond INTERNAL */

- (id)initWithJSONObject:(id)JSONObject;

/**
 * Create a JSON object which can serialized with NSJSONSerialization to pass to the receiver.
 */
- (id)JSONObject;

/** @endcond */

@end
