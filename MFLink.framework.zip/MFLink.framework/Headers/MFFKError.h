//
//  Copyright (c) 2013 - 2015 MoreFun (Beijing) Technology Co., Ltd.. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, MFFKErrorCode) {
    
    /**
     * Error code indicating a network I/O error.
     */
    MFFKErrorCodeNetworkError = 1,
    
    /**
     * Error code indicating that an operation has timed out.
     */
    MFFKErrorCodeTimeout = 2,
    
    /**
     * Error code indicating an authentication error.
     */
    MFFKErrorCodeDeviceAuthenticationFailure = 3,
    
    /**
     * Error code indicating that an invalid request was made.
     */
    MFFKErrorCodeInvalidRequest = 4,
    
    /**
     * Error code indicating that an in-progress request has been cancelled, most likely because
     * another action has preempted it.
     */
    MFFKErrorCodeCancelled = 5,
    
    /**
     * Error code indicating that the request was disallowed and could not be completed.
     */
    MFFKErrorCodeNotAllowed = 6,
    
    /**
     * Error code indicating that a requested application could not be found.
     */
    MFFKErrorCodeApplicationNotFound = 7,
    
    /**
     * Error code indicating that a requested application is not currently running.
     */
    MFFKErrorCodeApplicationNotRunning = 8,
    
    /**
     * Error code indicating the app entered the background.
     */
    MFFKErrorCodeAppDidEnterBackground = 91,
    
    /**
     * Error code indicating a disconnection occurred during the request.
     */
    MFFKErrorCodeDisconnected = 92,
    
    /**
     * Error code indicating that a request could not be made because the same type of request is
     * still in process.
     */
    MFFKErrorCodeDuplicateRequest = 93,
    
    /**
     * Error code indicating that a media load failed on the receiver side.
     */
    MFFKErrorCodeMediaLoadFailed = 94,
    
    /**
     * Error code indicating that a media media command failed because of the media player state.
     */
    MFFKErrorCodeInvalidMediaPlayerState = 95,
    
    /**
     * Error code indicating that an unknown, unexpected error has occurred.
     */
    MFFKErrorCodeUnknown = 99,
};

/**
 * The key for the customData JSON object associated with the error in the userInfo dictionary.
 */
extern NSString *const kMFFKErrorCustomDataKey;

/**
 * The class for all MFFK framework errors.
 *
 * @ingroup Utilities
 */
@interface MFFKError : NSError

/**
 * Returns the name of the enum value for a given error code.
 */
+ (NSString *)enumDescriptionForCode:(MFFKErrorCode)code;

/** @cond INTERNAL */

/**
 * Designated initializer.
 */
- (id)initWithCode:(MFFKErrorCode)code additionalUserInfo:(NSDictionary *)additionalUserInfo;

- (id)initWithCode:(MFFKErrorCode)code;

/** @endcond */

@end