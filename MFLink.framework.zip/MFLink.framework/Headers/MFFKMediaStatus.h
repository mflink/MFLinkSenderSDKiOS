//
//  Copyright (c) 2013 - 2015 MoreFun (Beijing) Technology Co., Ltd.. All rights reserved.
//

#import <Foundation/Foundation.h>

@class MFFKMediaInformation;

/** A flag (bitmask) indicating that a media item can be paused. */
extern const NSInteger kMFFKMediaCommandPause;

/** A flag (bitmask) indicating that a media item supports seeking. */
extern const NSInteger kMFFKMediaCommandSeek;

/** A flag (bitmask) indicating that a media item's audio volume can be changed. */
extern const NSInteger kMFFKMediaCommandSetVolume;

/** A flag (bitmask) indicating that a media item's audio can be muted. */
extern const NSInteger kMFFKMediaCommandToggleMute;

/** A flag (bitmask) indicating that a media item supports skipping forward. */
extern const NSInteger kMFFKMediaCommandSkipForward;

/** A flag (bitmask) indicating that a media item supports skipping backward. */
extern const NSInteger kMFFKMediaCommandSkipBackward;

/** */
typedef NS_ENUM(NSInteger, MFFKMediaPlayerState) {
    /** Constant indicating unknown player state. */
    MFFKMediaPlayerStateUnknown = 0,
    /** Constant indicating that the media player is idle. */
    MFFKMediaPlayerStateIdle = 1,
    /** Constant indicating that the media player is playing. */
    MFFKMediaPlayerStatePlaying = 2,
    /** Constant indicating that the media player is paused. */
    MFFKMediaPlayerStatePaused = 3,
    /** Constant indicating that the media player is buffering. */
    MFFKMediaPlayerStateBuffering = 4,
};

typedef NS_ENUM(NSInteger, MFFKMediaPlayerIdleReason) {
    /** Constant indicating that the player currently has no idle reason. */
    MFFKMediaPlayerIdleReasonNone = 0,
    
    /** Constant indicating that the player is idle because playback has finished. */
    MFFKMediaPlayerIdleReasonFinished = 1,
    
    /**
     * Constant indicating that the player is idle because playback has been cancelled in
     * response to a STOP command.
     */
    MFFKMediaPlayerIdleReasonCancelled = 2,
    
    /**
     * Constant indicating that the player is idle because playback has been interrupted by
     * a LOAD command.
     */
    MFFKMediaPlayerIdleReasonInterrupted = 3,
    
    /** Constant indicating that the player is idle because a playback error has occurred. */
    MFFKMediaPlayerIdleReasonError = 4,
};

/**
 * A class that holds status information about some media.
 */
@interface MFFKMediaStatus : NSObject

/**
 * The media session ID for this item.
 */
@property(nonatomic,readonly) NSInteger mediaSessionID;

/**
 * The current player state.
 */
@property(nonatomic,readonly) MFFKMediaPlayerState playerState;

/**
 * The current idle reason. This value is only meaningful if the player state is
 * MFFKMediaPlayerStateIdle.
 */
@property(nonatomic,readonly) MFFKMediaPlayerIdleReason idleReason;

/**
 * Gets the current stream playback rate. This will be negative if the stream is seeking
 * backwards, 0 if the stream is paused, 1 if the stream is playing normally, and some other
 * postive value if the stream is seeking forwards.
 */
@property(nonatomic,readonly) float playbackRate;

/**
 * The MFFKMediaInformation for this item.
 */
@property(nonatomic, strong, readonly) MFFKMediaInformation *mediaInformation;

/**
 * The current stream position, as an NSTimeInterval from the start of the stream.
 */
@property(nonatomic) NSTimeInterval streamPosition;

/**
 * The stream's volume.
 */
@property(nonatomic) float volume;

/**
 * The stream's mute state.
 */
@property(nonatomic,readonly) BOOL isMuted;

/**
 * Any custom data that is associated with the media item.
 */
@property(nonatomic, strong ,readonly) id customData;

/**
 * Designated initializer.
 *
 * @param mediaSessionID The media session ID.
 * @param mediaInformation The media information.
 */
- (id)initWithSessionID:(NSInteger)mediaSessionID
       mediaInformation:(MFFKMediaInformation *)mediaInformation;

/**
 * Checks if the stream supports a given control command.
 */
- (BOOL)isMediaCommandSupported:(NSInteger)command;

@end