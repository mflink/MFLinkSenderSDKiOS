//
//  Copyright (c) 2013 - 2015 MoreFun (Beijing) Technology Co., Ltd.. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <stdarg.h>

@protocol MFFKLoggerDelegate;

/**
 * A singleton object used for logging by the framework. By default, log messages are written to
 * NSLog() in debug builds and are discarded otherwise. If a delegate is assigned, the formatted
 * log messages are passed to the delegate instead.
 */

@interface MFFKLogger : NSObject

/** The delegate to pass log messages to. */
@property(nonatomic, weak) id<MFFKLoggerDelegate> delegate;
/**
 * Returns the MFFKLogger singleton instance.
 */
+ (MFFKLogger *)sharedInstance;

/**
 * Logs a message.
 *
 * @param function The calling function, normally <code>__func__</code>.
 * @param format The format string.
 */
- (void)logFromFunction:(const char *)function message:(NSString *)format, ...
NS_FORMAT_FUNCTION(2, 3);

@end

/**
 * The MFFKLogger delegate interface.
 */
@protocol MFFKLoggerDelegate

/**
 * Logs a message.
 *
 * @param function The calling function, normally <code>__func__</code>.
 * @param message The log message.
 */
- (void)logFromFunction:(const char *)function message:(NSString *)message;

@end


/**
 * @macro MFFKLog
 *
 * A convenience macro for logging to the MFFKLogger singleton. This is a drop-in replacement
 * for NSLog().
 */
#define MFFKLog(FORMAT, ...) \
[[MFFKLogger sharedInstance] logFromFunction:__func__ message:FORMAT, ##__VA_ARGS__]